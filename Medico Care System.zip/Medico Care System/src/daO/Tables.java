/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daO;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author rakes
 */
public class Tables {
    public static void main(String [] args){
        try{
            Connection con = ConnectionProvider.getCon();
            Statement st = con.createStatement();
            //st.executeUpdate("create table appuser(appuser_pk int AUTO_INCREMENT primary key,userRole varchar(200),name varchar(200),dob varchar(50),mobileNumber varchar(50),email varchar(200),username varchar(200),password varchar(50),address varchar(200))");
            //st.executeUpdate("insert into appuser(userRole,name,dob,mobileNumber,email,username,password,address)values('Admin','Admin','19-12-2003','9022541145','haritachippa668@gmail.com','admin','admin','India')")
            //st.executeUpdate("create table medicine(medicine_pk int AUTO_INCREMENT primary key,uniqueId varchar(200),Product varchar(200),pack varchar(200),companyName varchar(200),quantity bigint,expDate varchar(50),MRP float(20,4),SaleRate float(20,4),ProductValue float(20,4),Discount float(20,4),HSNcode bigint,GST int,GSTvalue float(20,4))");
            st.executeUpdate("create table bill(bill_pk int AUTO_INCREMENT primary key,customerName varchar (200),billId varchar(200),billDate varchar(50),totalPaid bigint,generatedBy varchar(50))");
            JOptionPane.showMessageDialog(null, "Table Created Successfully");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
