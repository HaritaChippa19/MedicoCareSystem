/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daO;

/**
 *
 * @author rakes
 */
public class PharmacyUtils {
    public static String billPath = "D:\\";
}
