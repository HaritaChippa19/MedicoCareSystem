
import daO.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class UpdateMedicine extends javax.swing.JFrame {
    public String numberPattern="^[0-9]*$";
    private float gstValue = 0.0f;
    
    public UpdateMedicine() {
        initComponents();
        setLocationRelativeTo(null);
        
    txtGST.getDocument().addDocumentListener(new DocumentListener() {
        @Override
        public void insertUpdate(DocumentEvent e) {
            calculateAndUpdateGstValue();
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            calculateAndUpdateGstValue();
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            calculateAndUpdateGstValue();
        }
    });
    
    // Add DocumentListener to Quantity field
    txtQuantity.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }
});

// Add DocumentListener to Sale Rate field
    txtSaleRate.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        calculateAndUpdateProductValue();
    }
});
    }
    
     private void calculateAndUpdateGstValue() {
    try {
        String gstPercentage = txtGST.getText();

        if (!gstPercentage.isEmpty()) {
            double gstPercentageValue = Double.parseDouble(gstPercentage);
            double productValue = Double.parseDouble(txtProductValue.getText());

            gstValue = (float) ((gstPercentageValue * productValue) / 100.0);
        }

        lblGSTvalue.setText(String.format("%.2f", gstValue));
    } catch (NumberFormatException ex) {
        lblGSTvalue.setText("Invalid");
    }
    
}
    
    private void calculateAndUpdateProductValue() {
    try {
        String quantityStr = txtQuantity.getText();
        String saleRateStr = txtSaleRate.getText();

        if (!quantityStr.isEmpty() && !saleRateStr.isEmpty()) {
            double quantity = Double.parseDouble(quantityStr);
            double saleRate = Double.parseDouble(saleRateStr);

            double productValue = quantity * saleRate;
            txtProductValue.setText(String.format("%.2f", productValue));
        } else {
            txtProductValue.setText("");
        }
    } catch (NumberFormatException ex) {
        txtProductValue.setText("");
    }
}

public float calculateGST() {
    try {
        String saleRateStr = txtSaleRate.getText();

        if (!saleRateStr.isEmpty()) {
            float saleRate = Float.parseFloat(saleRateStr);
            String gstStr = txtGST.getText();

            if (!gstStr.isEmpty()) {
                float gst = Float.parseFloat(gstStr);
                gstValue = (saleRate * gst) / 100.0f;
                return gstValue;
            } else {
                JOptionPane.showMessageDialog(null, "GST % field is required.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Sale Rate field is required.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }

    return 0.0f; // Return a default value in case of errors
}

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Close_btn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtProductName = new javax.swing.JTextField();
        Search_btn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtBatchNo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCompanyName = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtExpDate = new javax.swing.JTextField();
        Update_btn = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtPack = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtHSNcode = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtMRP = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtProductValue = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtDiscount = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtGST = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtSaleRate = new javax.swing.JTextField();
        lblGSTvalue = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Update Medicine");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(523, 13, -1, -1));

        Close_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/close.png"))); // NOI18N
        Close_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Close_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Close_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1244, 13, 33, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 64, 1289, 10));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("Batch NO.");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, -1, -1));

        txtProductName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtProductName, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 100, 510, -1));

        Search_btn.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Search_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Search.png"))); // NOI18N
        Search_btn.setText("Search");
        Search_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Search_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 100, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Product Name");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, -1));

        txtBatchNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtBatchNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 350, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("Manufactured By");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 360, -1, -1));

        txtCompanyName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txtCompanyName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCompanyNameActionPerformed(evt);
            }
        });
        getContentPane().add(txtCompanyName, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, 350, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("Quantity");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, -1, -1));

        txtQuantity.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtQuantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 500, 350, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setText("Expiry Date");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 550, -1, -1));

        txtExpDate.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtExpDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 590, 350, -1));

        Update_btn.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        Update_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Save.png"))); // NOI18N
        Update_btn.setText("Update");
        Update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Update_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 740, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setText("Pack");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 270, -1, -1));

        txtPack.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtPack, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 310, 350, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel8.setText("HSN Code");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 630, -1, -1));

        txtHSNcode.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txtHSNcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHSNcodeActionPerformed(evt);
            }
        });
        getContentPane().add(txtHSNcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 670, 350, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel10.setText("MRP");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 180, -1, -1));

        txtMRP.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtMRP, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 220, 350, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel11.setText("Sale Rate");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 270, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel12.setText("Product Value");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 360, -1, -1));

        txtProductValue.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtProductValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 400, 350, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel13.setText("Discount");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 450, -1, -1));

        txtDiscount.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtDiscount, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 500, 350, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setText("GST%");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 550, -1, -1));

        txtGST.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtGST, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 590, 350, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel15.setText("GST Value");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 640, -1, -1));

        txtSaleRate.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        getContentPane().add(txtSaleRate, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 310, 350, -1));

        lblGSTvalue.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblGSTvalue.setText("0.0");
        getContentPane().add(lblGSTvalue, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 680, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/WhiteBackground.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Close_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Close_btnActionPerformed
        
        setVisible(false);
    }//GEN-LAST:event_Close_btnActionPerformed

    private void Search_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search_btnActionPerformed
        
        int checkMedicineExist = 0;
        String name = txtProductName.getText();
        if(name.equals("")){
            JOptionPane.showMessageDialog(null, "Product Name field is required.");
        }else{
            try{
                Connection con = ConnectionProvider.getCon();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select *from medicine where Product='"+name+"'");
                while(rs.next()){
                    txtProductName.setEditable(false);
                    checkMedicineExist=1;
                    txtBatchNo.setText(rs.getString("uniqueId"));
                    txtPack.setText(rs.getString("pack"));
                    txtCompanyName.setText(rs.getString("companyName"));
                    txtQuantity.setText(rs.getString("quantity"));
                    txtExpDate.setText(rs.getString("expDate"));
                    txtHSNcode.setText(rs.getString("HSNcode"));
                    txtMRP.setText(String.valueOf((int) Float.parseFloat(rs.getString("MRP"))));
                    txtSaleRate.setText(String.valueOf((int) Float.parseFloat(rs.getString("SaleRate"))));
                    txtProductValue.setText(rs.getString("ProductValue"));
                    txtDiscount.setText(String.valueOf((int) Float.parseFloat(rs.getString("Discount"))));
                    txtGST.setText(rs.getString("GST"));
                    lblGSTvalue.setText(rs.getString("GSTvalue"));
                    
                    
                }
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            if(checkMedicineExist == 0){
                JOptionPane.showMessageDialog(null, "Product Name does't exist");
            }
        
        }
    }//GEN-LAST:event_Search_btnActionPerformed

    private void Update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_btnActionPerformed
        // TODO add your handling code here:
        String uniqueId = txtBatchNo.getText();
        String name = txtProductName.getText();
        String pack = txtPack.getText();
        String companyName = txtCompanyName.getText();
        String quantity = txtQuantity.getText();
        String expDate = txtExpDate.getText();
        String HSNcode = txtHSNcode.getText();
        String MRP = txtMRP.getText();
        String SaleRate = txtSaleRate.getText();
        String ProductValue =txtProductValue.getText();
        String Discount = txtDiscount.getText();
        String GST = txtGST.getText();
        String GSTvalue= lblGSTvalue.getText();
        
        
        if(uniqueId.equals("")){
            JOptionPane.showMessageDialog(null, "Batch No field is required.");
        }else if(companyName.equals("")){
            JOptionPane.showMessageDialog(null, "Company Name field is required.");
        }else if(quantity.equals("")){
            JOptionPane.showConfirmDialog(null, "Quantity field is required.");
        }else if(!quantity.matches(numberPattern)){
            JOptionPane.showMessageDialog(null, "Quantity field is invalid");
        }else if(expDate.equals("")){
            JOptionPane.showMessageDialog(null, "Expiry Date field is required");
        }else if(HSNcode.equals("")){
            JOptionPane.showMessageDialog(null, "HSNcode field is required");
        }else if(!HSNcode.matches(numberPattern)||numberPattern.length() !=8){
            JOptionPane.showMessageDialog(null, "HSN Code field is invalid.");
        }else if(MRP.equals("")){
            JOptionPane.showMessageDialog(null, "MRP field is required.");
        }else if(!MRP.matches(numberPattern)){
            JOptionPane.showMessageDialog(null, "MRP field is invalid.");
        }else if(SaleRate.equals("")){
            JOptionPane.showMessageDialog(null, "Sale Rate field is required.");
        }else if(!SaleRate.matches(numberPattern)){
            JOptionPane.showMessageDialog(null, "Sale Rate field is invalid.");
        }else if(Discount.equals("")){
            JOptionPane.showMessageDialog(null, "Discount field is required.");
        }else if(!Discount.matches(numberPattern)){
            JOptionPane.showMessageDialog(null, "Discount field is invalid.");
        }else if(GST.equals("")){
            JOptionPane.showMessageDialog(null, "GST % field is required.");
        }else if(!GST.matches(numberPattern)){
            JOptionPane.showMessageDialog(null, "GST % field is invalid.");
        }else{
            try{
                Connection con = ConnectionProvider.getCon();
                PreparedStatement ps = con.prepareStatement("update medicine set uniqueId=?,pack=?,companyName=?,quantity=?,expDate=?,HSNcode=?,MRP=?,SaleRate=?,ProductValue=?,Discount=?,GST=?,GSTvalue=? where Product=?");
                ps.setString(1, uniqueId);
                ps.setString(2,pack);
                ps.setString(3, companyName);
                ps.setString(4, quantity);
                ps.setString(5, expDate);
                ps.setString(6, HSNcode);
                ps.setString(7, MRP);
                ps.setString(8, SaleRate);
                ps.setString(9, ProductValue);
                ps.setString(10, Discount);
                ps.setString(11, GST);
                ps.setString(12, GSTvalue);
                ps.setString(13, name);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Medicine Updated Successfully");
                setVisible(false);
                new UpdateMedicine().setVisible(true);
                
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_Update_btnActionPerformed

    private void txtCompanyNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCompanyNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCompanyNameActionPerformed

    private void txtHSNcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHSNcodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHSNcodeActionPerformed
    private void formComponentShown(java.awt.event.ComponentEvent evt) {                                    
        // TODO add your handling code here:
        try{
            
            lblGSTvalue.setText(Double.toString(gstValue));
            calculateAndUpdateProductValue();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateMedicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateMedicine().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Close_btn;
    private javax.swing.JButton Search_btn;
    private javax.swing.JButton Update_btn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblGSTvalue;
    private javax.swing.JTextField txtBatchNo;
    private javax.swing.JTextField txtCompanyName;
    private javax.swing.JTextField txtDiscount;
    private javax.swing.JTextField txtExpDate;
    private javax.swing.JTextField txtGST;
    private javax.swing.JTextField txtHSNcode;
    private javax.swing.JTextField txtMRP;
    private javax.swing.JTextField txtPack;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtProductValue;
    private javax.swing.JTextField txtQuantity;
    private javax.swing.JTextField txtSaleRate;
    // End of variables declaration//GEN-END:variables
}
